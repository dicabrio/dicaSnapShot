<?php

$config = array(
	'timezone' => 'Europe/Berlin',
	'language' => array('nl_NL', 'Dutch Netherlands'),
);