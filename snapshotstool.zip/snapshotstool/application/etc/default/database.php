<?php

$config = array(

	'dbtype' => 'mysql',
	'dbhost' => '127.0.0.1',
	'dbname' => 'controlpanel',
	'dbuser' => 'root',
	'dbpass' => '',
);
