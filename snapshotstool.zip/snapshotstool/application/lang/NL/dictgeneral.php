<?php

$lang = array (
	'button' => array (
		'edit' => 'wijzig',
		'delete' => 'verwijder',
		'save' => 'opslaan',
		'cancel' => 'annuleer'
	),

	'logout' => 'Uitloggen',
	'dashboard' => 'Dashboard',
	'settings' => 'Settings',
	'formsubmit' => 'Verstuur',
	'choose' => 'Kies&hellip;',
	'title' => array(
		'textblock' => 'Tekstblok'
	),

	'date-notation' => 'd-m-Y',

	'months' => array(
		'1' => 'januari',
		'2' => 'februari',
		'3' => 'maart',
		'4' => 'april',
		'5' => 'mei',
		'6' => 'juni',
		'7' => 'juli',
		'8' => 'augustus',
		'9' => 'september',
		'10' => 'oktober',
		'11' => 'november',
		'12' => 'december'
	),
);

