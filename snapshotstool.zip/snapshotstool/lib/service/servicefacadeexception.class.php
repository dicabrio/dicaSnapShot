<?php

class ServiceFacadeException extends Exception
{

}
?>