<?php

class ProtocolException extends Exception
{
}

?>