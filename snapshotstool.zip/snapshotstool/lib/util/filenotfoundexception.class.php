<?php
class FileNotFoundException extends Exception {}
