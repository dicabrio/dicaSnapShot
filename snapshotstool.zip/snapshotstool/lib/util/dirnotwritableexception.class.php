<?php

class DirNotWritableException extends Exception {}