<?php
/**
 * 
 */
interface FormHandler {

	/**
	 * @param Form $oForm
	 */
	public function handleForm(Form $oForm);
}